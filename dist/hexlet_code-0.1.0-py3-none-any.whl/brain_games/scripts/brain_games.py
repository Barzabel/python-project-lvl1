#!/usr/bin/env python
# -*- coding:utf-8 -*-
from brain_games.games.cli import welcome_user


def main():
    welcome_user()


if __name__ == '__main__':
    main()
